CREATE DATABASE RailwayManagementSystem;
USE RailwayManagementSystem;
CREATE TABLE Stations (
    StationID INT PRIMARY KEY,
    StationName VARCHAR(100) NOT NULL,
    Location VARCHAR(100) NOT NULL
);
INSERT INTO Stations ( StationID ,StationName, Location) VALUES 
(1,'Karachi Cantt', 'Karachi'),
(2,'Lahore Junction', 'Lahore'),
(3,'Rawalpindi', 'Rawalpindi'),
(4,'Quetta', 'Quetta'),
(5,'Peshawar Cantt', 'Peshawar'),
(6,'Multan Cantt', 'Multan'),
(7,'Faisalabad', 'Faisalabad'),
(8,'Hyderabad Junction', 'Hyderabad'),
(9,'Sialkot Junction', 'Sialkot'),
(10,'Gujranwala', 'Gujranwala');
select * from Stations;
CREATE TABLE Trains (
    TrainID INT PRIMARY KEY ,
    TrainName VARCHAR(100) NOT NULL,
    TrainType VARCHAR(50)
);
INSERT INTO Trains (TrainID,TrainName, TrainType) VALUES 
(1,'Karachi Express', 'Express'),
(2,'Green Line Express', 'Express'),
(3,'Tezgam Express', 'Express'),
(4,'Millat Express', 'Express'),
(5,'Pakistan Express', 'Express'),
(6,'Awam Express', 'Express'),
(7,'Jinnah Express', 'Express'),
(8,'Shalimar Express', 'Express'),
(9,'Khyber Mail', 'Express'),
(10,'Bolan Mail', 'Express');
select * from Trains;
CREATE TABLE Passengers (
    PassengerID INT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Phone_No varchar(50),
);
INSERT INTO Passengers (PassengerID ,FirstName, LastName,    Phone_No) VALUES 
(1,'Ahmed', 'Khan', 19850115),
(2,'Ayesha', 'Bibi', 19900723),
(3,'Muhammad', 'Ali', 19781102),
(4,'Fatima', 'Riaz', 19820312),
(5,'Omar', 'Sheikh', 19870425),
(6,'Sara', 'Iqbal', 19920830),
(7,'Hassan', 'Mehmood', 19751211),
(8,'Zara', 'Ahmad', 19880614),
(9,'Bilal', 'Hussain', 19950220),
(10,'Mariam', 'Chaudhry', 19910905);
select * from Passengers;
CREATE TABLE Schedules (
    ScheduleID INT PRIMARY KEY,
    TrainID INT,
    DepartureStationID INT,
    ArrivalStationID INT,
    DepartureTime DATETIME,
    ArrivalTime DATETIME,
    FOREIGN KEY (TrainID) REFERENCES Trains(TrainID),
    FOREIGN KEY (DepartureStationID) REFERENCES Stations(StationID),
    FOREIGN KEY (ArrivalStationID) REFERENCES Stations(StationID)
);
INSERT INTO Schedules ( ScheduleID,TrainID, DepartureStationID, ArrivalStationID, DepartureTime, ArrivalTime) VALUES 
(1,1, 1, 2, '2024-07-01 08:00:00', '2024-07-01 18:00:00'),  -- Karachi Cantt to Lahore Junction
(2,2, 2, 3, '2024-07-01 10:00:00', '2024-07-01 20:00:00'),  -- Lahore Junction to Rawalpindi
(3,3, 3, 4, '2024-07-02 06:00:00', '2024-07-02 22:00:00'),  -- Rawalpindi to Quetta
(4,4, 4, 5, '2024-07-02 12:00:00', '2024-07-03 08:00:00'),  -- Quetta to Peshawar Cantt
(5,5, 5, 6, '2024-07-02 14:00:00', '2024-07-03 02:00:00'),  -- Peshawar Cantt to Multan Cantt
(6,6, 6, 7, '2024-07-03 09:00:00', '2024-07-03 19:00:00'),  -- Multan Cantt to Faisalabad
(7,7, 7, 8, '2024-07-03 07:00:00', '2024-07-03 17:00:00'),  -- Faisalabad to Hyderabad Junction
(8,8, 8, 9, '2024-07-03 13:00:00', '2024-07-03 23:00:00'),  -- Hyderabad Junction to Sialkot Junction
(9,9, 9, 10, '2024-07-04 08:00:00', '2024-07-04 18:00:00'),  -- Sialkot Junction to Gujranwala
(10,10, 10, 1, '2024-07-04 09:00:00', '2024-07-04 19:00:00'); -- Gujranwala to Karachi CanttInsert into Tickets
select * from Schedules;
CREATE TABLE Tickets (
    TicketID INT PRIMARY KEY,
    ScheduleID INT,
    PassengerID INT,
    SeatNumber VARCHAR(10),
    TicketPrice DECIMAL(10, 2),
    FOREIGN KEY (ScheduleID) REFERENCES Schedules(ScheduleID),
    FOREIGN KEY (PassengerID) REFERENCES Passengers(PassengerID)
);
INSERT INTO Tickets (TicketID ,ScheduleID, PassengerID, SeatNumber, TicketPrice) VALUES 
(1,1, 1, 'A1', 1500.00), -- Karachi Express from Karachi Cantt to Lahore Junction
(2,2, 2, 'B2', 1200.00), -- Green Line Express from Lahore Junction to Rawalpindi
(3,3, 3, 'C3', 2000.00), -- Tezgam Express from Rawalpindi to Quetta
(4,4, 4, 'D4', 2500.00), -- Millat Express from Quetta to Peshawar Cantt
(5,5, 5, 'E5', 1300.00), -- Pakistan Express from Peshawar Cantt to Multan Cantt
(6,6, 6, 'F6', 1100.00), -- Awam Express from Multan Cantt to Faisalabad
(7,7, 7, 'G7', 1800.00), -- Jinnah Express from Faisalabad to Hyderabad Junction
(8,8, 8, 'H8', 1400.00), -- Shalimar Express from Hyderabad Junction to Sialkot Junction
(9,9, 9, 'I9', 1600.00), -- Khyber Mail from Sialkot Junction to Gujranwala
(10,10, 10, 'J10', 1700.00); -- Bolan Mail from Gujranwala to Karachi Cantt
select * from Tickets;
SELECT 
    Trains.TrainName,
    Schedules.DepartureTime,
    Schedules.ArrivalTime,
    DepartureStation.StationName AS DepartureStation,
    ArrivalStation.StationName AS ArrivalStation
FROM 
    Schedules
INNER JOIN Trains ON Schedules.TrainID = Trains.TrainID
INNER JOIN Stations AS DepartureStation ON Schedules.DepartureStationID = DepartureStation.StationID
INNER JOIN Stations AS ArrivalStation ON Schedules.ArrivalStationID = ArrivalStation.StationID;

SELECT 
    Passengers.FirstName,
    Passengers.LastName,
    Tickets.SeatNumber,
    Tickets.TicketPrice
FROM 
    Tickets
INNER JOIN Passengers ON Tickets.PassengerID = Passengers.PassengerID
WHERE 
    Tickets.ScheduleID = 4;

